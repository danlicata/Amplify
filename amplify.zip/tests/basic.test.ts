import { expect, test } from "vitest";

test("basic addition [unit", () => {
	expect(2 + 2).toBe(4);
});
